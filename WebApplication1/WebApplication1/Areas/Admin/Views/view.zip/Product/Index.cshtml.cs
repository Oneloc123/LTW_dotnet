using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Areas.Admin.Views.Product
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
