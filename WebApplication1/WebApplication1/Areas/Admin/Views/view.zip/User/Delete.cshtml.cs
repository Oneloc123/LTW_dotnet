using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Areas.Admin.Views.User
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
