using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Areas.Admin.Views.User
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
